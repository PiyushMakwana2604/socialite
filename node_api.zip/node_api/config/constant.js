var global = {
    APP_NAME: 'Goggle Showcase',
    CATEGORY_URL: 'http://localhost/piyushproject/ser_tu_app_mongodb/api/',
    CATEGORY_IMAGE: 'public/category_img/',
    PRODUCT_URL: 'http://localhost/piyushtrainee/april_2023/18_april/api/',
    PRODUCT_IMAGE: 'public/product_img/',
    BASE_URL_WITHOUT_API: 'http://localhost/piyushtrainee/april_2023/18_april/',
    BASE_URL: 'http://localhost/piyushtrainee/april_2023/18_april/api/',
    PORT_BASE_URL: 'http://localhost:8484/'
}
module.exports = global;