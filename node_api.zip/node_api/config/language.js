/** 
 * Load all the language file here
*/
const en = require('../language/en');

const Languages = {
	'en': en
}

module.exports = Languages;