const checkValidatorRules = {

    addPostValidation: {
        message: "required"
        // post_media: "",
    },
}

module.exports = checkValidatorRules;

